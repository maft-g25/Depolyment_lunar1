export default {
    "data": {
        "footerData": [
            {
                id: 9,
                // title1: 'Vist my profiles or check : ',
                title2: 'LunarEstates Construction :',
                // location: 'Yosan Electric provides professional and reliable electric services including domestic installations, repairs, and maintenance in London, Oxford, UK',
                email: 'lunarestates@outlook.com',
                phone: '+260972344075',
                phone2: '+447983316617',
                // title3:'Opening hours /Emergency :',
                // descr: 'Business Hours: Every day from 8am to 5pm except Sunday. ',
                // contact: 'Emergency Calls: Contact me anytime.',
    
    
            },
        ]

    }
}
